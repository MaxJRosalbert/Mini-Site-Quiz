/*//////////////////////////////////////////////////////////////////////////////
                            LES QUESTIONS DU QUIZ
//////////////////////////////////////////////////////////////////////////////*/

let questionnaire = [
    {
        titre: "Quel Dieu Grec représente les enfers?",
        choix: ["Zeus", "Arès", "Hades", "Hélios"],
        bonneReponse: 2
    },
    {
        titre: "De quel mythologie provient la Déesse Amaterasu?",
        choix: ["Nordique", "Japonaise", "Grecoromaine", "Égyptienne"],
        bonneReponse: 1
    },
    {
        titre: "Lequel de ces Dieux n'est pas représenté par une planête?",
        choix: ["Athéna", "Zeus", "Poséidon", "hermes"],
        bonneReponse: 0
    },
    {
        titre: "Quel Dieu de la mythologie nordique fut à l'origine du marteau mjollnir? ",
        choix: ["Odin", "Thor", "Hell", "Loki"],
        bonneReponse: 3
    },
    {
        titre: "Lequel de ces Dieux ne symbolise pas le soleil?",
        choix: ["Hélios", "fujin", "Ra", "Amaterasu"],
        bonneReponse: 1
    },
    {
        titre: "Qui a demander à Hercule d'exécuter les 12 travaux?",
        choix: ["Tésée", "Cronos", "Athéna", "Zeus"],
        bonneReponse: 3
    },
    {
        titre: "Lequel de Ces Héros s'est distingué lors de la guerre de Troie",
        choix: ["Achile", "Jason", "Ulisse", "Persé"],
        bonneReponse: 0
    },
    {
        titre: "Lequel de ces Dieux ne symbolise pas la foudre?",
        choix: ["Thor", "Raijin", "Shazam", "Zeus"],
        bonneReponse: 2
    },
    {
        titre: "Lequel de ces Dieux ne représente pas la mort?",
        choix: ["Thanatos", "Anubis", "Hell", "Hades"],
        bonneReponse: 3
    },
    {
        titre: "Qui fut consideré comme le messagers des Dieux?",
        choix: ["Loki", "Hermes", "Persée", "Héra"],
        bonneReponse: 1
    },
]

let questionPose = [

    
]